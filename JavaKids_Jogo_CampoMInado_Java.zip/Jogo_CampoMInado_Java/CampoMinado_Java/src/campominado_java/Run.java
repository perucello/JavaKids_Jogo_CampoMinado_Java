
package campominado_java;


public class Run {

    public static void main(String[] args) {
        Jogo jogar = new Jogo();
    }
    
}
